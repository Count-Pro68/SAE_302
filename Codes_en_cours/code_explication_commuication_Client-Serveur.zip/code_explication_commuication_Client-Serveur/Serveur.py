"""
Implémenter en Python un programme « Serveur » qui :

créé un socket d’écoute et l’associe au port 63000
le met à l’état d’écoute et attend qu’un client s’y connecte
affiche l’adresse du client qui vient de se connecter
attend la réception d’un message de la part du client
le renvoie aussitôt au client en rajoutant à la fin : "\nPrésent !"
ferme les connexions
"""
import socket
socket_ecoute = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

socket_ecoute.bind(('', 63000))

socket_ecoute.listen(1)
print("[Serveur] En attente d'une connexion...")

connexion_client, adresse_client = socket_ecoute.accept()
print(f"[Serveur] Client connecté depuis {adresse_client}")

message = connexion_client.recv(1024).decode()
print(f"[Serveur] Message reçu : {message}")

response = message + "\nPrésent !"
connexion_client.sendall(response.encode())

connexion_client.close()
socket_ecoute.close()
print("[Serveur] Connexion fermée")