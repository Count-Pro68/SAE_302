"""
Implémenter en Python un programme « Client » qui :

crée un socket
demande une connexion au serveur d’adresse ('localhost', 63000)
‘localhost' est le nom d’hôte qui désigne l’interface de bouclage (loopback interface), c’est à dire la machine locale. Cela correspond à l’adresse IP '127.0.0.1')
Le client et le serveur sont sur la même machine ici !
envoie un message "Serveur es-tu là ?"
affiche la réponse du serveur
ferme la connexion
"""
import socket

connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

connexion_serveur.connect(("localhost", 63000))

message = "Serveur es-tu là ?"
connexion_serveur.sendall(message.encode())
#connexion_serveur.send(b'Bonjour serveur !")

response = connexion_serveur.recv(1024).decode()
print("[Client] Réponse du serveur :")
print(response)

connexion_serveur.close()