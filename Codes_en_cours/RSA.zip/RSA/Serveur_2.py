import socket, threading

class serveur():
    def __init__(self):
        self.port_ecoute_generique = 63000
        # Création du socket d'écoute en IPv4 avec le protocole TCP
        self.socket_ecoute = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connexion = False
        self.connexion_client = None
    
    def Ecoute(self):
        # Liaison du socket au port 63000 sur l’interface locale
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        self.socket_ecoute.bind((ip, self.port_ecoute_generique))

        # Mise du socket en mode écoute
        self.socket_ecoute.listen()
        print("[Serveur] En attente d'une connexion...")
        
    def Connexion(self):
        # Acceptation de la connexion d’un client
        # Un nouveau socket est créé pour la communication avec ce client
        self.connexion_client , adresse_client = self.socket_ecoute.accept()
        print(f"[Serveur] Client connecté depuis {adresse_client}")

        message = self.connexion_client .recv(1024).decode()
        print(f"[Serveur] Message de connexion du client reçu : {message}")
        if message == "b":
            print(f"[Serveur] Le message est correcte.")
            self.connexion_client .sendall("b".encode())
            print(f"[Serveur] Message de connexion envoyé au client")
            return True
        else:
            return False
   
    def Reception(self): 
        # Réception du message du client (1024 octets maximum)
        # 1024 correspond à la taille maximale du buffer, ce n’est pas un port
        message = self.connexion_client .recv(1024).decode()
        print(f"[Serveur] Message reçu : {message}")
    
    def Envoi(self):
        # Saisie de la réponse du serveur
        reponse = input("Saisissez votre réponse : ")
        # Envoi de la réponse au client
        self.connexion_client .sendall(reponse.encode())
        print(f"[Serveur] Message envoyé : {reponse}")
    
    def Fin(self):
        print("[Serveur] Connexion fermée")
        self.connexion_client .close()
        self.socket_ecoute.close()

if __name__ == "__main__":
    s = serveur()
    s.Ecoute()
    if s.Connexion():
        t_reception = threading.Thread(target=s.Reception)
        t_envoie = threading.Thread(target=s.Envoi)

        t_reception.start()
        t_envoie.start()

        t_reception.join()
        t_envoie.join()
    else:
        print("aucune connexion")