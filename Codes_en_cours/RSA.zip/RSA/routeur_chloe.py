from key import RSA
from action_key import Action

class DB:
    """
    Class pour stocker les informations comme les clés et éviter par erreur d'en regénérer
    """
    def __init__(self):
        #création des clés
        self.cle_publique, self.cle_privee = RSA().demande_cles()
db_global = DB()

class routeur(DB):
    def __init__(self,message:str):
        #héritage
        super().__init__()
        #message
        if not isinstance(message, (str, int)):
            raise TypeError("le message doit être une une chaîne de caractères")
        self.message = message

    def conteneurisation(self):
        """
        Cette fonction devra permettre de conteneuriser le message et de le crypter
        :return: le return sera en binaire (fonction b"")
        """
        return Action(self.message,db_global).chiffrement()
    
    def deconteneurisation(self):
        """
        Cette fonction devra permettre de déconteneuriser le message et de le déchiffrer
        :return: le return sera en clair (lecture humaine)
        """
        return Action(self.message,db_global).dechiffrement()

if __name__ == "__main__":
    # il est nécessaire de créer un objet db pour éviter de recharger des clés et d'avoir une incompatibilité de la clé privée avec la clé publique
    db_global = DB()
    message = "test RSA"
    print("message original :", message,"\n")

    message_chiffre = routeur(message).conteneurisation()
    print("message chiffré :", message_chiffre, "\n")

    message_dechiffre = routeur(message_chiffre).deconteneurisation()
    print("message déchiffré :", message_dechiffre)

    