import socket 
import threading


class client ():
    def __init__(self):
        self.connexion_serveur = None
        self.actif = True
 
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        self.connexion_serveur.connect(("localhost", 63000))
        
    def ACK(self):
        self.connexion_serveur.sendall("Bonjour".encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        return reponse
        
    def Envoie(self):
        while self.actif:
            message = input("Saisissez votre message : ")
            if not self.actif:
                break
            try:
                self.connexion_serveur.sendall(message.encode())
            except OSError:
                break

    def Reception(self):
        """
        la gestion d'erreur est ici nécessaire voir vitale car elle permet d'éviter un crash quand le serveur ferme et que lui continue d'écouter
        """
        while self.actif:
            try:
                reponse = self.connexion_serveur.recv(1024).decode()
                if reponse == "fin":
                    print("[Serveur] Fin de connexion")
                    self.actif = False
                    try:
                        self.connexion_serveur.shutdown(socket.SHUT_RDWR)
                    except:
                        pass
                    self.connexion_serveur.close()
                    break
                print(f"\n[Serveur] {reponse}")
            except (OSError, ConnectionResetError):
                break
    def Fin(self):
        self.connexion_serveur.close()
        
if __name__ == "__main__":
    c = client()
    c.Connexion()

    c.ACK()  # ← MANQUANT

    t_reception = threading.Thread(target=c.Reception)
    t_envoie = threading.Thread(target=c.Envoie)

    t_reception.start()
    t_envoie.start()

    t_reception.join()
    t_envoie.join()

    print("[Client] Programme terminé")

