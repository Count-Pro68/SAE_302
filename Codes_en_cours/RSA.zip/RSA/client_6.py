import socket, threading

class routeur_serveur ():
    def __init__(self):
        self.connexion_serveur = None
        hostname = socket.gethostname()
        self.ip = socket.gethostbyname(hostname)
        self.port_ecoute_generique = 63000
        self.taille_buffer = 1024
        self.type = 'b'
        self.message = f"{self.type};{self.port_ecoute_generique};{self.ip}"#type message, port, @iP, clé publique...# et sérialisation du message
        
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        """
        il faut mettre l'adrese ip du serveur
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        """
        self.connexion_serveur.connect((self.ip, self.port_ecoute_generique))
        
    def ACK(self):
        self.connexion_serveur.sendall(self.message.encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(self.taille_buffer).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        if reponse == "f":
            self.actif = False
            return False
        return True
        
        
class routeur_routeur(routeur_serveur):
    def __init__(self):
        super().__init__()
        self.actif = True

    def Reception(self):
            print("reception")
            reponse = self.connexion_serveur.recv(self.taille_buffer).decode()
            if reponse == "f":
                print("f")
                self.actif = False
            elif reponse == "d":
                print("d")
                self.Envoi()

    def Envoi(self):
        while self.actif:
            message = input("Saisissez votre message : ")
            self.connexion_serveur.sendall(message.encode())
            print(f"[Client] Message envoyé : {message}")

    def Fin(self):
        self.connexion_serveur.close()#libère definitivement le socket
        print("[Client] Connexion fermée")
        
if __name__ == "__main__":
    rr = routeur_routeur()

    rr.Connexion()
    rr.actif = rr.ACK()

    if rr.actif:
        t_envoie = threading.Thread(target=rr.Envoi)
        t_reception = threading.Thread(target=rr.Reception)

        t_envoie.start()
        t_reception.start()

        t_envoie.join()
        t_reception.join()

    rr.Fin()