import socket, threading

class client ():
    def __init__(self):
        self.connexion_serveur = None
        self.actif = True
        
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        self.connexion_serveur.connect((ip, 63000))
        
    def ACK(self):
        self.connexion_serveur.sendall("b".encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        if reponse == "fin":
            self.Fin()
            return False
        return True
        
    def Echange(self):
        while self.actif:
            message = input("Saisissez votre message : ")
            self.connexion_serveur.sendall(message.encode())
            print(f"[Client] Message envoyé : {message}")

            reponse = self.connexion_serveur.recv(1024).decode()
            print(f"[Client] Réponse du serveur : {reponse}")

            if reponse == "fin":
                self.actif = False
                break
        
    def Fin(self):
        self.connexion_serveur.close()#libère definitivement le socket
        print("[Client] Connexion fermée")
        
if __name__ == "__main__":
    c = client()
    c.Connexion()
    if c.ACK():
        c.Echange
    c.Fin