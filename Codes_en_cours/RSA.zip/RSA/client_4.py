import socket 
import threading


class client ():
    def __init__(self):
        self.connexion_serveur = None
        self.actif = True
        self.attente_reponse = threading.Event()
        self.attente_reponse.set()

 
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        self.connexion_serveur.connect(("localhost", 63000))
        
    def ACK(self):
        self.connexion_serveur.sendall("Bonjour".encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        return reponse
        
    def Envoie(self):
        while self.actif:
            #wait() il suspendra son exécution sur cette ligne, tant qu'il n'aura pas reçu la valeur de retour de fin, indiquant que son processus enfant est complété.
            self.attente_reponse.wait()  # bloque tant que pas de réponse
            message = input(""Saisissez votre message : "")
            #La fonction clear() en Python supprime tous les éléments d'une liste
            self.attente_reponse.clear()
            try:
                self.connexion_serveur.sendall(message.encode())
            except OSError:
                break


    def Reception(self):
        while self.actif:
            try:
                reponse = self.connexion_serveur.recv(1024).decode()
                if reponse == "fin":
                    print("\n[Serveur] Fin de connexion")
                    self.actif = False
                    self.attente_reponse.set()#création d'un set
                    self.connexion_serveur.close()
                    break
                print(f"\n[Serveur] {reponse}")
                self.attente_reponse.set()  # autorise le prochain message
            except:
                break

                
    def Fin(self):
        self.connexion_serveur.close()
        
if __name__ == "__main__":
    c = client()
    c.Connexion()

    c.ACK()  

    t_reception = threading.Thread(target=c.Reception)
    t_envoie = threading.Thread(target=c.Envoie)

    t_reception.start()
    t_envoie.start()

    t_reception.join()
    t_envoie.join()

    print("[Client] Programme terminé")