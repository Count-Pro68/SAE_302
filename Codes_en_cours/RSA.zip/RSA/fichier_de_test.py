from key import RSA
from action_key import Action
from routeur_chloe import DB

if __name__ == "__main__":
    while True:
        print("Test n°0: test du fonctionnement du fichier Key ;")
        print("Test n°1: test du fonctionnement du fichier action_key et routeur, fonctionnement simple (chiffrement-déchiffrement)")
        print("Test n°2: test du fonctionnement du fichier action_key et routeur (Db), fonctionnement avec message trop important (génération d'une erreur);")
        print()
        try:
            nb = int(input("Choisir un test, (uniquement la valeur numérique) : "))
        except ValueError:
            print("Il faut saisir une valeur numérique")
            continue
        if nb == 0:
            print(RSA().demande_cles())
        elif nb == 1:
            # Test 1 : Chiffrement et déchiffrement d'un texte
            db = DB()
            #il est nécessaire de crée un objet db pour éviter de recharger des clé et d'avoir une incompatibilité de la clé privée avec la clé publique
            texte = "test RSA"
            print("texte original :", texte)

            texte_chiffre = Action(texte,db).chiffrement()
            print("texte chiffré :", texte_chiffre)

            texte_dechiffre = Action(texte_chiffre,db).dechiffrement()
            print("texte déchiffré :", texte_dechiffre)
        elif nb == 2:
            #Test 2: Chiffrement et dechiffrement d'un text trop long (doit générer une erreur)
            db = DB()
            texte = "test RSA pour un message trop long: Le chiffrement RSA est un algorithme de cryptographie asymétrique, très utilisé dans le commerce électronique, et plus généralement pour échanger des données confidentielles sur Internet. Cet algorithme a été décrit en 1977 par Ronald Rivest, Adi Shamir et Leonard Adleman. RSA a été breveté par le Massachusetts Institute of Technology en 1983 aux États-Unis. Le brevet a expiré le 21 septembre 2000. "
            print("texte original :", texte)

            texte_chiffre = Action(texte, db).chiffrement()
            print("texte chiffré :", texte_chiffre)

            texte_dechiffre = Action(texte_chiffre, db).dechiffrement()
            print("texte déchiffré :", texte_dechiffre)
        else:
            #Test nb inconnue: Il n'y a aps encore de test pour cette valeur
            print(f"il n'y a pas de test correspondant au nombre {nb}")
        
        while True:
            choix = str(input("Voulez-vous continuer ? (o/n) : ").strip().lower()) # lstrip.lower renvoie l'élément en paramètre (qui est un str) en minuscule
            if choix in ("n", "non"):
                print("Fin du test")
                exit()
            elif choix in ("o", "oui"):
                break
            else:
                print("Réponse non reconnue, veuillez répondre par 'o' ou 'n'.")
    print("Fin du test")
    print("Le message qui suit est normale :)")

