import socket

# Création du socket d'écoute en IPv4 avec le protocole TCP
socket_ecoute = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Liaison du socket au port 63000 sur l’interface locale
socket_ecoute.bind(('', 63000))

# Mise du socket en mode écoute
socket_ecoute.listen()
print("[Serveur] En attente d'une connexion...")

# Acceptation de la connexion d’un client
# Un nouveau socket est créé pour la communication avec ce client
connexion_client, adresse_client = socket_ecoute.accept()
print(f"[Serveur] Client connecté depuis {adresse_client}")

message = connexion_client.recv(1024).decode()
print(f"[Serveur] Message de connexion du client reçu : {message}")
if message == "Bonjour":
    print(f"[Serveur] Le message est correcte.")
    connexion_client.sendall("Bonjour".encode())
    print(f"[Serveur] Message de connexion envoyé au client")
        
    while True:
        # Réception du message du client (1024 octets maximum)
        # 1024 correspond à la taille maximale du buffer, ce n’est pas un port
        message = connexion_client.recv(1024).decode()
        print(f"[Serveur] Message reçu : {message}")

        # Saisie de la réponse du serveur
        response = input("Saisissez votre réponse : ")

        # Envoi de la réponse au client
        connexion_client.sendall(response.encode())
        print(f"[Serveur] Message envoyé : {message}")

        while True:
            # Demande si l’on souhaite continuer la communication
            choix = input("Voulez-vous continuer ? (o/n) : ").strip().lower()

            if choix in ("o", "oui"):
                break

            elif choix in ("n", "non"):
                # Envoi du message de fin au client
                message = "fin"
                connexion_client.sendall(message.encode())

                # Fermeture propre des connexions
                connexion_client.close()
                socket_ecoute.close()
                print("[Serveur] Connexion fermée")
                exit()

            else:
                print("Réponse non reconnue, veuillez répondre par 'o' ou 'n'.")
else:
    print(f"[Serveur] Le message est incorrecte.")
    print("Pas de connexion")
    connexion_client.close()
    socket_ecoute.close()