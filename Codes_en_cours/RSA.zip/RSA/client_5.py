import socket, threading

class client ():
    def __init__(self):
        self.connexion_serveur = None
        self.saisie = False
        #pour éviter que es deux threads ne fassent la même chose en même temps
        #il est soit libre soit utilisé par un threads, 
        #analogie d'une clé pour arréter la machien avec deux utilisaterus qui ce la partage
        self.lock = threading.Lock()
        #Event va agir comme un feu bicolor, soit rouge soir vert
        self.autorisation_saisie = threading.Event()
        self.autorisation_saisie.clear()  # au début : INTERDIT de saisir

        
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        self.connexion_serveur.connect((ip, 63000))
        
    def ACK(self):
        self.connexion_serveur.sendall("Bonjour".encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        if reponse == "fin":
            self.Fin()
            return False
        else:
            self.saisie = True
            self.autorisation_saisie.set()  # autorise la première saisie
        return True
        
    def Envoie(self):
        message = input("Saisissez votre message : ")
        self.connexion_serveur.sendall(message.encode())
        print(f"[Client] Message envoyé : {message}")
        self.autorisation_saisie.clear()  #interdit nouvelle saisie
        while self.saisie: 
            self.autorisation_saisie.wait()  # bloque tant que pas de réponse
            if not self.saisie:
                break
            message = input("Saisissez votre message : ")
            if not self.saisie:
                break
            try:
                # sendall() est utilisé à la place de send()
                # afin de garantir l’envoi complet du message
                self.connexion_serveur.sendall(message.encode())
                print(f"[Client] Message envoyé : {message}")
                self.autorisation_saisie.clear()  #interdit nouvelle saisie
            except OSError:
                break
        print(f"[Client] Saisie de message impossible, pas de connexion établie")

    def Reception(self):
        while self.saisie:
            try:
                # Réception de la réponse du serveur (1024 octets maximum)
                reponse = self.connexion_serveur.recv(1024).decode()
                if not reponse:
                    break
                print(f"[Client] Réponse du serveur : {reponse}")
                if reponse == "fin":
                    self.saisie = False
                    break
            except (OSError, ConnectionResetError):
                break
        print(f"[Client] Reception de message impossible, pas de connexion établie")
        self.Fin()
        return reponse
        
    def Fin(self):
        with self.lock:
            #si la clé est libre (analogie de qui à la clé de l'arret machine
            if self.connexion_serveur:#est-ce qu'il esxite toujours
                try:
                    self.connexion_serveur.shutdown(socket.SHUT_RDWR)#coupe l'écriture et la lecture
                except: # si le socket est déjà fini ont ignore
                    pass
                self.connexion_serveur.close()#libère definitivement le socket
                self.connexion_serveur = None#il n'y a plus de connexion
        self.saisie = False
        print("[Client] Connexion fermée")
        
if __name__ == "__main__":
    c = client()
    c.Connexion()
    if c.ACK():
        t_reception = threading.Thread(target=c.Reception)
        t_envoie = threading.Thread(target=c.Envoie)

        t_reception.start()
        t_envoie.start()

        t_reception.join()
        t_envoie.join()