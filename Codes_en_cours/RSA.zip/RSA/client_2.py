import socket 

class client ():
    def __init__(self):
        self.connexion_serveur = None
        
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        self.connexion_serveur.connect(("localhost", 63000))
        
    def ACK(self):
        self.connexion_serveur.sendall("Bonjour".encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        return reponse
        
    def Envoie(self):
        message = input("Saisissez votre message : ")
        # sendall() est utilisé à la place de send()
        # afin de garantir l’envoi complet du message
        self.connexion_serveur.sendall(message.encode())
        print(f"[Client] Message envoyé au serveur : {message}")

    def Reception(self):
        # Réception de la réponse du serveur (1024 octets maximum)
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse du serveur : {reponse}")
        return reponse
        
    def Fin(self):
        self.connexion_serveur.close()
        
if __name__ == "__main__":
    c = client()
    c.Connexion()
    reponse = c.ACK()
    print("connexion et ack")
    if reponse == "fin":
        print("if")
        c.Fin()
    else:
        print("else")
        while True:
            print("boucle while")
            c.Envoie()
            reponse = c.Reception()
            if reponse == "fin":
                print("fin")
                c.Fin()