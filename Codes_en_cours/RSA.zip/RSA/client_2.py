import socket, threading

class client ():
    def __init__(self):
        self.connexion_serveur = None
        self.saisie = None
        
    def Connexion(self):
        # Création du socket en IPv4 avec le protocole TCP
        self.connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Demande de connexion au serveur local sur le port 63000
        self.connexion_serveur.connect(("localhost", 63000))
        
    def ACK(self):
        self.connexion_serveur.sendall("Bonjour".encode())
        print(f"[Client] Message de connexion envoyé au serveur")
        reponse = self.connexion_serveur.recv(1024).decode()
        print(f"[Client] Réponse de connexion de client reçu : {reponse}")
        if reponse == "fin":
            Fin()
        else:
            self.saisie = True
        return reponse
        
    def Envoie(self):
        while self.saisie: 
            message = input("Saisissez votre message : ")
            # sendall() est utilisé à la place de send()
            # afin de garantir l’envoi complet du message
            self.connexion_serveur.sendall(message.encode())
            print(f"[Client] Message envoyé au serveur : {message}")
        print(f"[Client] Saisie de message impossible, pas de connexion établie")

    def Reception(self):
        while self.saisie:
            # Réception de la réponse du serveur (1024 octets maximum)
            reponse = self.connexion_serveur.recv(1024).decode()
            print(f"[Client] Réponse du serveur : {reponse}")
            if reponse == "fin":
                self.saisie = False
                Fin()
        print(f"[Client] Reception de message impossible, pas de connexion établie")
        Fin()
        return reponse
        
    def Fin(self):
        self.connexion_serveur.close()
        
if __name__ == "__main__":
    c = client()
    c.Connexion()
    c.ACK()
    
    t_reception = threading.Thread(target=c.Reception)
    t_envoie = threading.Thread(target=c.Envoie)

    t_reception.start()
    t_envoie.start()

    t_reception.join()
    t_envoie.join()