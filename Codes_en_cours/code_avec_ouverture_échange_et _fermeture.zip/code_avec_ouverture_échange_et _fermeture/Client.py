import socket

# Création du socket en IPv4 avec le protocole TCP
connexion_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Demande de connexion au serveur local sur le port 63000
connexion_serveur.connect(("localhost", 63000))

while True:
    message = "Serveur es-tu là ?"

    # sendall() est utilisé à la place de send()
    # afin de garantir l’envoi complet du message
    connexion_serveur.sendall(message.encode())
    print(f"[Client] Message envoyé au serveur : {message}")

    # Réception de la réponse du serveur (1024 octets maximum)
    response = connexion_serveur.recv(1024).decode()
    print(f"[Client] Réponse du serveur : {response}")

    if response == "fin":
        break

# Fermeture de la connexion
connexion_serveur.close()

